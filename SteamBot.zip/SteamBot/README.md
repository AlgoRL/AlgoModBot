```Steam Bot```

> This is a Steam Bot, basically verifies users using Epic Games or Steam!

---

**Set up Guide**

1. Go to https://discord.com/developers/applications.
2. Click on "New Application"

![alt text](/Images/Screenshot%202023-05-16%20130257.png)

3. After you finish naming your application, Go to Bot and click "Add Bot". This will allow Discord to create a bot for you.
4. Once you have setup the bot, invite the bot by going to OAuth2 > URL Generator, and edit the options shown below.
 - **Enable**
    > ```bot```, ```applications.commands```.
5. Go down to "BOTS PERMISSIONS", Enable Administrator and copy and paste the URL given below, and enter it to your browser. Select the server you want the bot be invited.

**I would like to say that because of the APIs for ensuring if user is using the right account for verifying, I have used Steam API for this.**

By getting the link from here, [Click here](https://steamcommunity.com/dev/apikey), you will be able to get the Steam API key.

**Let's get onto getting the bot to access the google Drive.**

> Before we continue, I would like to address that this proceedure will allow the bot to get access to your google Drive, it depends if you selected your account or another account that is yours as well.

> In this google drive set up for the Discord bot, please proceed to this link.(0:36-8:07)  https://youtu.be/1y0-IfRW114?t=36


**Now back to the file.**

***In this folder, it contains bot's code/ content. We will be setting up the bot's configurations.***

1. Go to .env, if not, you can create one in the bot's folder, like so:
```env
TOKEN = "DiscordBotTokenHere"
MONGODB_STRING = "MongoDBStringHere"

STEAM_TOKEN = "SteamTokenHere"

CLIENT_ID = "ClientID"
CLIENT_SECRET = "ClientSecret"
REDIRECT_URL = "https://developers.google.com/oauthplayground"

REFRESH_TOKEN = "RefreshTokenFromGoogle"

VERIFIED_ROLE = "VerifyRoleIDHere"
```
 There you should be able to see the secrets of the bot itself. For example, the password for the bot to login Discord and the database itself.

2. You will be able to see something like this.

![alt text](/Images/Screenshot%202023-05-16%20142112.png)

3. In the Discord Developer Portal, go to Bot > TOKEN. Copy the token from there and replace "YourTokenHere" with your token, do not remove the quotation marks as it will cause the bot to malfunction. Again, The token itself is a secret key for the bot to login in Discord. Therefore, it should not be reveal to other people. This will lead them to get access to your bot.

4. Let's set up the key for the bot to get access on the Database. It is required for the bot to do so, this will allow the bot to pick up the last session if the bot has crashed caused by an error or other possible issue.

5. This project is using Mongo DB for storing data. To set up the Database for the bot, please refer the tutorial here as it explains in detail. Watch from 0:00-5:48. If you have the key from MongoDB, please do the following. [click here](https://www.youtube.com/watch?v=BEkyfqlbVRw)

6. Once you have set up Database for the bot, please replace the Secret keys, which is REFRESH_TOKEN, STEAM_TOKEN, CLIENT_ID, CLIENT_SECRET, not REDIRECT_URL.

7. Copy the Verified Role ID from your Discord Server and replace it wih VERIFIED_ROLE.


**Finally...**

1. Open a terminal or simply click CTRL along with `.

2. run  ```npm init``` to edit the project.

3. run ```npm install`` to install all the packages that the project needs.

4. Type ```node .``` to start the bot.

**Yay! You have made it to the end! If you have any problems setting up the bot, please do let me know, hope you enjoy the final product of "Steam Bot"!**
